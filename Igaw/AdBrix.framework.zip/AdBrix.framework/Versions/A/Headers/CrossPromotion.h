//
//  CrossPromotion.h
//  AdBrixLib
//
//  Created by wonje,song on 2015. 5. 26..
//  Copyright (c) 2015년 wonje,song. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CrossPromotion : NSObject

+ (void)showAD:(NSString *)activityName parentViewController:(UIViewController *)parentViewController;

@end
